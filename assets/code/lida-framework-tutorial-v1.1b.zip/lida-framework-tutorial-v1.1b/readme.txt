This is the tutorial distribution for the LIDA Framework tutorial given at the Artificial General Intelligence 2011 conference (AGI-11). *Note this tutorial is designed specifically for LIDA framework version 1.1b is not 100% compatible with other framework versions.*
This distribution contains the following files:

1. tutorialProjects/				- contains ready-made NetBeans projects for the tutorial exercises
2. LIDA-Framework-Tutorial-v1.0.pdf - tutorial manual of exercises
2. readme.txt 						- this file

The following contents can be used to create your own Agent project (see Appendix in 
3. lida-framework-v1.1b.jar  		- LIDA framework jar file
4. lida-framework-v1.1b-doc.zip 	- archive of framework's javadoc
5. lida-framework-v1.1b-src.zip 	- archive of framework's source files
6. lib/								- directory of jar files required by the LIDA framework 
									- Jung 2.0.1 jung.sourceforge.net/ for the GUI.
									- Colt 1.2.0 acs.lbl.gov/software/colt/ for Jung and SDM.
									- JFreeChart 1.0.13 jfree.org/jfreechart/ for the GUI
7. LIDA-framework-non-commerical-v1.0.pdf  - LIDA framework non-commercial license agreement
8. LidaXMLSchema.xsd				- xml schema file for agent.xml declaration files
9. LidaFactories.xsd				- xml schema file for factoryData.xml file
									
Contact 
For general inquiries or inquiries about commercial licenses please write 'ccrg@cs.memphis.edu'
To report bugs please write 'ccrg.memphis@gmail.com'

For more information visit http://ccrg.cs.memphis.edu/framework.html

Acknowledgements
Javier Snaider – LIDA Framework main designer, developer, and team leader
Ryan McCall – LIDA Framework co-developer and designer
CCRG Computational Group - developing and testing
Stan Franklin – CCRG director and the LIDA Model founder
