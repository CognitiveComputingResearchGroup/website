/*******************************************************************************
 * Copyright (c) 2009, 2011 The University of Memphis.  All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the LIDA Software Framework Non-Commercial License v1.0 
 *  which accompanies this distribution, and is available at
 * http://ccrg.cs.memphis.edu/assets/papers/2010/LIDA-framework-non-commercial-v1.0.pdf
 *******************************************************************************/
package run;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.memphis.ccrg.lida.framework.Agent;
import edu.memphis.ccrg.lida.framework.initialization.AgentStarter;

/**
 * Loads agent configuration Properties file.
 * Creates and runs a {@link Agent} agent based on loaded config file. 
 * @author Ryan J. McCall
 */
public class RunExampleAgent {
	
	private static final Logger logger = Logger.getLogger(RunExampleAgent.class.getCanonicalName());
	private static final String propertiesPath = "configs/lidaConfig.properties";	
	
	/**
	 * Creates a Properties object and loads the 
	 * LIDA Configuration properties file into it. 
	 * Then calls LidaStarter, passing Properties.
	 * @param args Path for properties file
	 */
	public static void main(String args[]) {
		Properties properties = new Properties();
		try{
			properties.load(new BufferedReader(new FileReader(propertiesPath)));		
		}catch(IOException e){ 
			e.printStackTrace();
			logger.log(Level.SEVERE, "LIDA configuration properties file not found");
			return;
		}
		
		try{
			AgentStarter.start(properties);
		}catch(Exception e){
			e.printStackTrace();
			logger.log(Level.SEVERE, "Unhandled exception thrown from LidaStarter.start()");
		}	
	}

}
