/*******************************************************************************
 * Copyright (c) 2009, 2011 The University of Memphis.  All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the LIDA Software Framework Non-Commercial License v1.0 
 *  which accompanies this distribution, and is available at
 * http://ccrg.cs.memphis.edu/assets/papers/2010/LIDA-framework-non-commercial-v1.0.pdf
 *******************************************************************************/
package intialization;


import java.util.Map;

import pam.BasicDetector;
import pam.BottomRightDetector;
import pam.TopLeftDetector;

import edu.memphis.ccrg.lida.framework.Agent;
import edu.memphis.ccrg.lida.framework.ModuleName;
import edu.memphis.ccrg.lida.framework.initialization.FullyInitializable;
import edu.memphis.ccrg.lida.framework.initialization.Initializer;
import edu.memphis.ccrg.lida.framework.shared.ElementFactory;
import edu.memphis.ccrg.lida.framework.shared.Link;
import edu.memphis.ccrg.lida.pam.PamNodeImpl;
import edu.memphis.ccrg.lida.pam.PerceptualAssociativeMemory;
import edu.memphis.ccrg.lida.pam.PerceptualAssociativeMemoryImpl;
import edu.memphis.ccrg.lida.pam.PropagationStrategy;
import edu.memphis.ccrg.lida.pam.UpscalePropagationStrategy;
import edu.memphis.ccrg.lida.pam.tasks.DetectionAlgorithm;
import edu.memphis.ccrg.lida.sensorymemory.SensoryMemory;

public class PamInitializer implements Initializer {

	@Override
	public void initModule(FullyInitializable module, Agent lida, Map<String, ?> params) {		
		PerceptualAssociativeMemory pam = (PerceptualAssociativeMemory) module;
		SensoryMemory sm = (SensoryMemory) lida
				.getSubmodule(ModuleName.SensoryMemory);

		// Nodes
		ElementFactory factory = ElementFactory.getInstance();
		PamNodeImpl wood = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"wood");
		pam.addDefaultNode(wood);
		PamNodeImpl gold = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"gold");
		pam.addDefaultNode(gold);
		PamNodeImpl metal = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"metal");
		pam.addDefaultNode(metal);
		PamNodeImpl solid = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"solid");
		pam.addDefaultNode(solid);
		PamNodeImpl iron = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"iron");
		pam.addDefaultNode(iron);
		PamNodeImpl plastic = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"plastic");
		pam.addDefaultNode(plastic);
		PamNodeImpl noMetal = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"noMetal");
		pam.addDefaultNode(noMetal);
		PamNodeImpl topLeft = (PamNodeImpl) factory.getNode("PamNodeImpl",
				"topLeft");
		pam.addDefaultNode(topLeft);
		PamNodeImpl bottomRight = (PamNodeImpl) factory.getNode(
				"PamNodeImpl", "bottomRight");
		pam.addDefaultNode(bottomRight);
		// Links
		Link l = factory.getLink("PamLinkImpl", gold, metal, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", metal, solid, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", iron, metal, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", wood, noMetal, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", plastic, noMetal, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", metal, noMetal, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", wood, solid, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);
		
		l = factory.getLink("PamLinkImpl", topLeft, wood, PerceptualAssociativeMemoryImpl.NONE, "slowDecay", "slowExcite", 1.0, 0.0);
		pam.addDefaultLink(l);

		// Feature detectors
		DetectionAlgorithm fd = new BasicDetector(gold, sm, pam);
		fd.setTicksPerStep(5);
		pam.addPerceptualAlgorithm(fd);
		fd = new BasicDetector(iron, sm, pam);
		fd.setTicksPerStep(3);
		pam.addPerceptualAlgorithm(fd);
		fd = new BasicDetector(wood, sm, pam);
		fd.setTicksPerStep(2);
		pam.addPerceptualAlgorithm(fd);
		fd = new TopLeftDetector(topLeft, sm, pam);
		fd.setTicksPerStep(7);
		pam.addPerceptualAlgorithm(fd);
		fd = new BottomRightDetector(bottomRight, sm, pam);
		fd.setTicksPerStep(3);
		pam.addPerceptualAlgorithm(fd);

		PropagationStrategy b = new UpscalePropagationStrategy();
		pam.setPropagationStrategy(b);
		//driver.setInitialTasks(pam.getFeatureDetectors());
	}

}
