/*******************************************************************************
 * Copyright (c) 2009, 2011 The University of Memphis.  All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the LIDA Software Framework Non-Commercial License v1.0 
 *  which accompanies this distribution, and is available at
 * http://ccrg.cs.memphis.edu/assets/papers/2010/LIDA-framework-non-commercial-v1.0.pdf
 *******************************************************************************/
/**
 * 
 */
package intialization;


import java.util.Map;

import edu.memphis.ccrg.lida.attentioncodelets.AttentionCodelet;
import edu.memphis.ccrg.lida.attentioncodelets.AttentionCodeletModule;
import edu.memphis.ccrg.lida.attentioncodelets.BasicAttentionCodelet;
import edu.memphis.ccrg.lida.framework.Agent;
import edu.memphis.ccrg.lida.framework.ModuleName;
import edu.memphis.ccrg.lida.framework.initialization.FullyInitializable;
import edu.memphis.ccrg.lida.framework.initialization.Initializer;
import edu.memphis.ccrg.lida.framework.initialization.ModuleUsage;
import edu.memphis.ccrg.lida.framework.shared.ElementFactory;
import edu.memphis.ccrg.lida.globalworkspace.GlobalWorkspace;
import edu.memphis.ccrg.lida.workspace.workspacebuffers.WorkspaceBuffer;

/**
 * @author Javier Snaider
 *
 */
public class AttentionModuleInitializer implements Initializer {

	/* (non-Javadoc)
	 * @see edu.memphis.ccrg.lida.framework.initialization.Initializer#initModule(edu.memphis.ccrg.lida.framework.initialization.Initializable, edu.memphis.ccrg.lida.framework.Lida, java.util.Properties)
	 */
	@Override
	public void initModule(FullyInitializable module, Agent lida, Map<String, ?> params) {
		AttentionCodeletModule driver = (AttentionCodeletModule)module;
		GlobalWorkspace gw = (GlobalWorkspace)lida.getSubmodule(ModuleName.GlobalWorkspace);
		WorkspaceBuffer csm = (WorkspaceBuffer)lida.getSubmodule(ModuleName.Workspace).getSubmodule(ModuleName.CurrentSituationalModel);
		
		ElementFactory factory = ElementFactory.getInstance();
		AttentionCodelet ac=(AttentionCodelet)factory.getCodelet(BasicAttentionCodelet.class.getSimpleName() , 20, 1.0, -1.0, null);
		ac.setAssociatedModule(gw, ModuleUsage.TO_WRITE_TO);
		ac.setAssociatedModule(csm, ModuleUsage.TO_READ_FROM);
		driver.addCodelet(ac);
	}

}
