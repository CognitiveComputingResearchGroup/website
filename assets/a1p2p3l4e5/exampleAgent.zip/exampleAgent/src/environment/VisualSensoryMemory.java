/*******************************************************************************
 * Copyright (c) 2009, 2011 The University of Memphis.  All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the LIDA Software Framework Non-Commercial License v1.0 
 *  which accompanies this distribution, and is available at
 * http://ccrg.cs.memphis.edu/assets/papers/2010/LIDA-framework-non-commercial-v1.0.pdf
 *******************************************************************************/
package environment;

import java.util.Map;

import edu.memphis.ccrg.lida.sensorymemory.SensoryMemoryImpl;

/**
 * 
 * @author Ryan J. McCall
 *
 */
public class VisualSensoryMemory extends SensoryMemoryImpl {

	/**
	 * A matrix representation representing the beginning of 
	 * the agent's understanding.
	 * This variable or whatever variables you declare should be 
	 * modified using 'synchronized(this)' as feature detectors
	 * running in separate threads will access this variable(s) as well
	 */
	private double[][] sensoryScene = new double[5][5];
	
	/**
	 * This method is called repeatedly by SensoryMemoryDriver.
	 * You can control this rate by changing the 'ticksperstep' 
	 * parameter for SensoryMemoryDriver in lida.xml
	 * 
	 * Notice environment is inherited from SensoryMemoryImpl.
	 * Module content depends on what environment you are using.
	 * 
	 */
	@Override
	public void runSensors() {
		//Environment is inherited from SensoryMemoryImpl
		//Module content depends on your environment
		double[][] environContent = (double[][]) environment.getState(null);
		//Add processing code
		
		//Store the results of processing
		synchronized(this){
			sensoryScene = environContent;
		}
	}

	
	@Override
	public Object getModuleContent(Object... params) {
		if(params.length == 0)
			return sensoryScene;
		if("sensoryScene".equalsIgnoreCase((String) params[0]))
			return sensoryScene;
		return null;
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public Object getSensoryContent(String modality, Map<String, Object> params) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void decayModule(long ticks) {
		// TODO Auto-generated method stub
		
	}

}
