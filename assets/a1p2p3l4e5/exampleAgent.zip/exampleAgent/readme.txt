This archive contains the following files:
readme.txt 				- this file
src					- source files of the example agent
configs					- configuration files for the example agent
LIDA-framework-non-commerical-v1.0.pdf  - the non-commercial license agreement this code is released under

Disclaimer
This is a simple example agent to test the installation of LIDA framework v1.0b.
More comprehensive examples will accompany future releaese.

Running the example agent with the LIDA framework
1. Obatain the LIDA framework distribution 'lida-framework-v1.0b'
2. Compile the example agent project, 'src', including in the classpath the LIDA framework library: 
'lida-framework-v1.0b/lida-framework-v1.0b.jar', and all jars in 'lida-framework-v1.0b/lib'
3. Run the file 'run.RunExampleAgent.java'

Contact 
For general inquiries or inquiries about commercial licenses please write 'ccrg@cs.memphis.edu'
To report bugs please write 'ccrg.memphis@gmail.com'

For more information visit http://ccrg.cs.memphis.edu/framework.html