This archive contains the following files:
readme.txt 						- this file
lida-framework-v1.0b.jar  		- the LIDA framework library
lida-framework-v1.0b-doc.zip 	- archive of the LIDA framework's javadoc
lida-framework-v1.0b-src.zip 	- archive of the LIDA framework's source files
LIDA-framework-non-commerical-v1.0.pdf  - the non-commercial license agreement this code is released under
lib/							- other jar files required to run the LIDA framework 
									- Jung 2.0.1 http://jung.sourceforge.net/ for the GUI.
									- Colt 1.2.0 acs.lbl.gov/software/colt/ for the Jung and SDM.
									
Contact 
For general inquiries or inquiries about commercial licenses please write 'ccrg@cs.memphis.edu'
To report bugs please write 'ccrg.memphis@gmail.com'

For more information visit: http://ccrg.cs.memphis.edu/framework.html

Acknowledgements
Javier Snaider – LIDA Framework main designer, developer, and team leader
Ryan McCall – LIDA Framework co-developer and designer
CCRG Computational Group - developing and testing
Stan Franklin – CCRG director and LIDA Model founder 